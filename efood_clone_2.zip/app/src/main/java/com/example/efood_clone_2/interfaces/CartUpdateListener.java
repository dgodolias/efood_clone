package com.example.efood_clone_2.interfaces;

public interface CartUpdateListener {
    void onCartUpdated();
}